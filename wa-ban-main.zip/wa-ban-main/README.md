# Wa-Ban for TERMUX
# WHATSAPP BANNING TOOL
## AIM
It is a tool for banning whatsapp number only in india
## INSTALLATION

apt update

apt upgrade

pkg install toilet -y

pkg install git -y

git clone https://github.com/ooo9204/wa-ban

cd wa-ban

chmod +x *

bash waban.sh

## THIS TOOL IS FOR EDUCATIONAL PERPOSE ............ NOT TO HARM ANYONE

